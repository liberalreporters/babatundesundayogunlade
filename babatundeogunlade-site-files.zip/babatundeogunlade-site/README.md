# babatundeogunlade.com

Official campaign portal for Hon. Babatunde Sunday Ogunlade.
Static site (HTML + Tailwind CDN + vanilla JS), hosted on Vercel.

## Repository layout

```
index.html           single-page site (six pages, hash navigation)
404.html             not-found page
robots.txt           crawler rules
sitemap.xml          sitemap
site.webmanifest     browser metadata
vercel.json          headers, caching, clean URLs
assets/              favicon and icons
scripts/check_site.py   pre-deploy checks
docs/OPERATIONS.md   how to change, deploy, roll back, maintain
.github/             CI workflow, issue and PR templates
```
Photos (`4418043.jpg`, `876469f9-...`) live in the repo root next to `index.html`.

## Working on the site
Read [docs/OPERATIONS.md](docs/OPERATIONS.md). In short: branch, pull request,
check the Vercel preview, merge.

## Before launch
- Replace `YOUR_FORM_ID` in `index.html` with the Formspree form ID.
- Replace placeholder social links.
- Verify every factual claim on the site.
