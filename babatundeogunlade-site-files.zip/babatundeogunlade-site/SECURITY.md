# Security

If you find a security problem with this website, do not post it publicly.
Open a private report under the repository's **Security → Report a vulnerability**
tab, or contact the site owner directly.

Never commit passwords, API keys, or form secrets to this repository.
The Formspree form ID in `index.html` is public by design; it is not a secret.
